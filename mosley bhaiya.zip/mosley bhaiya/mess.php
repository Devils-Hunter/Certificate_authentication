<?php 
	
	session_start();
	$email = $_POST['t2'];

	$_SESSION['email'] = $email;

	$con=mysqli_connect('localhost','root','deepak','mosley_bhaiya');

	$sql = "SELECT * FROM `number` WHERE `email` = '$email'";

	$query = mysqli_query($con,$sql);



	$run = mysqli_fetch_assoc($query);


	$name =  $run['name'];

	
?>



<!doctype html>
<html lang="en">
  <head>
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Generate A Certificate</title>
    <link href="https://fonts.googleapis.com/css2?family=Rowdies:wght@700&display=swap" rel="stylesheet"> 
  </head>
  <body style="background-color:  #c2e6c2">
    
    <img src="Certificate.png" class="img-fluid" alt="Responsive image">

    <hr class="w-75">
    <marquee style="font-weight: bolder;" class="text-dark">Please Download Your Certificate</marquee>
    <hr class="w-75">

    &nbsp;
    &nbsp;
    
    
    <div class="container text-center">
    	<h1 style="font-size: 60px;font-weight: bolder;font-style: italic;font-family: 'Rowdies', cursive;">Welcome</h1>
    	<hr class="w-75">

  		<h1 style="font-size: 50px;font-weight: bolder;"><?php  echo $name ?></h1>
  		<hr class="w-75">
  		<a download href="data.php"><h4 style="font-size: 50px;text-decoration: underline;font-weight: bolder;"><?php  echo $name ?>!  Please Download Your Certificate</h4></a>
  		<hr class="w-75">
    </div>


   
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>