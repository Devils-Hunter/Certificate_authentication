<?php
		
	echo "Data was Fetching.....";
	 $con=mysqli_connect('localhost','root','deepak','mosley_bhaiya');

	if($con){
		echo "Data was Connected";
	}
	else
	{
		echo "data was not connected";
	}
	
	





 ?>