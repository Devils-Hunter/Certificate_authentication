<?php
	
	session_start();

	$email = $_SESSION['email'];

	echo $email;

	$con=mysqli_connect('localhost','root','deepak','mosley_bhaiya');

	$sql = "SELECT * FROM `number` WHERE `email` = '$email'";

	$query = mysqli_query($con,$sql);



	$run = mysqli_fetch_assoc($query);


	$name =  $run['name'];

	echo $name;

	header('content-type:image/jpeg');

	$font = realpath('arial.TTF');
	$image = imagecreatefromjpeg("certifiate.jpeg");
	$color = imagecolorallocate($image, 51, 51, 102);
	imagefttext($image, 48,0,390,400,$color, $font, $name);
	imagejpeg($image,"certi/$name.jpg");



	header("Location:certi/".$name.'.jpg');	
	imagedestroy($image);


	



 ?>